# -*- coding: utf-8 -*-

"""Top-level package for Randomly."""

__author__ = """Luis Aparicio, Mykola Bordyuh"""
__email__ = 'la2666@cumc.columbia.edu, mb4125@cumc.columbia.edu'
__version__ = '0.1.0'

from .randomly import Rm