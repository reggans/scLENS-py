'''Aestehetic color palettes for visualization'''

pallete_50 = ['#9af764', '#3e82fc', '#fe0002', '#f4d054', '#ed0dd9',
              '#13eac9', '#e4cbff', '#b1d27b', '#ad8150', '#601ef9',
              '#ff9408', '#75bbfd', '#fdb0c0', '#a50055', '#4da409',
              '#c04e01', '#d2bd0a', '#ada587', '#0504aa', '#650021',
              '#d0fefe', '#a8ff04', '#fe46a5', '#bc13fe', '#fdff52',
              '#f2ab15', '#fd4659', '#ff724c', '#cba560', '#cbf85f',
              '#78d1b6', '#9d0216', '#874c62', '#8b88f8', '#05472a',
              '#b17261', '#a4be5c', '#742802', '#3e82fc', '#eedc5b',
              '#a8a495', '#fffe71', '#c1c6fc', '#b17261', '#ff5b00',
              '#f10c45', '#3e82fc', '#de9dac', '#f10c45', '#056eee',
              '#e6daa6', '#eedc5b', '#c87606', '#9dbcd4', '#56ae57',
              '#49759c', '#d8dcd6']


pallete_16 = ['#a2cffe', '#87a922', '#ffa62b', '#f8481c', '#cffdbc',
              '#a6814c', '#a484ac', '#fc86aa', '#952e8f', '#02ccfe',
              '#2000b1', '#009337', '#ad0afd', '#3c9992', '#d8dcd6',
              '#cb6843']

